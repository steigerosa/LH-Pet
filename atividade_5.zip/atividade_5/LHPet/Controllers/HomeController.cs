﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LHPet.Models;

namespace LHPet.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        Clientee cliente1 = new Clientee( 01 , "Arthur Ferreira", "857.032.950 41-41", "art@sp.senai. br", "LOK");
        Clientee cliente2 = new Clientee( 02 , "Magno sanches", "698.478.950 41-41", "mmm@sp.senai. br", "38");
        Clientee cliente3 = new Clientee( 03 , "ada wong", "010.011.950 41-41", "re4@sp.senai. br", "leon");
        Clientee cliente4 = new Clientee( 04 , "lionel messe", "874.111.950 41-41", "barça@sp.senai. br", "cr7");
        Clientee cliente5 = new Clientee( 05 , "craque neto", "556.762.950 41-41", "band@sp.senai. br", "tite");

        List<Clientee> listaClientees = new List<Clientee>();
        listaClientees.Add(cliente1);
        listaClientees.Add(cliente2);
        listaClientees.Add(cliente3);
        listaClientees.Add(cliente4);
        listaClientees.Add(cliente5);
        ViewBag.listaClientees = listaClientees;
        
    
            
        Fornecedores fornecedor1 = new Fornecedores(01 , "C# PET S/A", "14.182.102/0001-80", "c sharp@pet.org");
        Fornecedores fornecedor2 = new Fornecedores(02 , "Ctrl Alt Dog" , "15.836.698/0001 57", "ctrl@alt.dog.");
        Fornecedores fornecedor3 = new Fornecedores(03 ," BootsPet INC", "40.810.224/0001 83","boots.pet@gatomania.");      
        Fornecedores fornecedor4 = new Fornecedores(04 ," Tik Tok Dogs", "87.945.350/0001 09","noisnamidia@tiktokdogs.");
        Fornecedores fornecedor5 = new Fornecedores(05 ,"Bifinho Forever", "18.760.614/0001 37","contato@bff.");

        List<Fornecedores> listaFornecedores = new List<Fornecedores>();
        listaFornecedores.Add(fornecedor1);
        listaFornecedores.Add(fornecedor2);
        listaFornecedores.Add(fornecedor3);
        listaFornecedores.Add(fornecedor4);
        listaFornecedores.Add(fornecedor5);
        ViewBag.listaFornecedores = listaFornecedores;

        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
